# Telegram Shop Bot Pro - Premium Version

## Overview
This bot allows users to browse products, add to cart, and pay using Stripe, Crypto, YooKassa, or Manual Payment. 
Admins manage products, orders, and settings via web panel.

## Setup

1. Install Node.js >=16
2. Copy `.env.example` to `.env` and fill all keys (Telegram Bot, Stripe, Crypto, YooKassa, Admin login)
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start admin panel (port 3000 by default):
   ```bash
   npm run admin
   ```
5. Start Telegram bot:
   ```bash
   npm start
   ```

## Features
- Browse products & add to cart
- Multi-payment support: Stripe, Crypto, YooKassa, Manual
- Admin panel: manage products, orders, payment keys
- License Key protection for resale
- Real-time order notifications in Telegram